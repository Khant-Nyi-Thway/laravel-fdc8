<?php
    return [
        "change-language" => "Change Language",
        "change" => "Change",
        "greeting" => "Hello!",
        "english" => "English",
        "myanmar" => "Myanmar"
    ];