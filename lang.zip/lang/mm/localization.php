<?php
    return [
        "change-language" => "ဘာသာစကားပြောင်းပါ",
        "change" => "ပြောင်းပါ",
        "greeting" => "မာကလာပင်"
    ];